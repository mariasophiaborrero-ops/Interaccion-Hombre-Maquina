function setup() {
  createCanvas(400, 400);
  frameRate(30);
  colorMode(HSB);
}

function draw() {
  background(0, 200, 15);

  let x = width * 0.5 + 100 * sin(frameCount * 0.05);
  let y = height * 0.5;

  
  rect(x, y, 40, 40);
  rect(x + 15, y + 20, 10, 20 );
  rect(x + 5, y + 5, 10, 10);
  rect(x + 25, y + 5, 10, 10);
  rect(x + 25, y - 20, 65, 20);
  rect(x + 40, y, 50, 40);
  triangle( x, y, x + 40, y, x + 20, y - 40 );
  rect(x + 19, y - 50, 2,15);
  rect(x + 12, y - 45, 15,2);
}