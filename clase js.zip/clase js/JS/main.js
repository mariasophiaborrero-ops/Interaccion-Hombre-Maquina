alert ("callate la jeta")
var a = 5;
var b = 1;

var isA = true;
var isB = false;

var stringA = "calayo";
var stringB = "tucucu";

console.log(stringA)
console.log(stringB)


var suma = a + b;
console.log(suma)

function sayHello() {
  return "ola";
}