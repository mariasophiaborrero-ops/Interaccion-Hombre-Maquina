var a = 0

function clicBoton(n){
    a = n+a
    console.log(a);
}


var vida=100;
var ataque = 20;
var defensa = 10;

var evida=50;
var eataque= 20;
var edefensa = 15;


function CalcularAtaque(){
    evida -= ataque -edefensa;
    var isEnemigo = Math.random
    console.log(isEnemigo);

    if (isEnemigo>=0.5)
    { vida -= eataque}

    if (vida<=0){
        alert ("perdista juas juas")
    }
    


    if (isEnemigo>=0.5){
        vida -= eataque - defensa
        console.log(vida)
    }
    if (evida <= 0){
        alert("ganaste")
    }
    
}